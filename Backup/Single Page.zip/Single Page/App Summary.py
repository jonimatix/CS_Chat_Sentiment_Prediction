import streamlit as st
import pandas as pd
import numpy as np
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import plotly.figure_factory as ff

from configparser import ConfigParser
import pyodbc

from datetime import datetime
import os
import gc
import time
import io
import sys
import re
from os import path

import importlib
from helperFunctions import *
import helperFunctions
from utils import *
import utils
importlib.reload(helperFunctions)
importlib.reload(utils)

print(os.getcwd())
warnings.filterwarnings('ignore')

# Debug the application by running this in command line:
# cd /d C:\
# cd C:\Users\Jonathanm\Desktop\LiveChat Chats EDA\
# streamlit run "App Summary.py" --server.port 8501 --server.address "10.13.50.37"

input_path = './Input/'
output_path = './Output/'

# Switch to wide page view
st.set_page_config(layout="wide", page_title='Chat Sentiment',  # page_icon=favicon,
                   initial_sidebar_state='auto')
# favicon being an object of the same kind as the one you should provide st.image() with (ie. a PIL array for example) or a string (url or local file path)

KEEPALIVEHOURS = 1  # Keep cache alive for 1 hours (value in seconds)


@st.cache(ttl=60*60*KEEPALIVEHOURS)
def get_dataset_main():  # Country, UserID
    config = ConfigParser()
    config.read('db.ini')

    server = config['dwh']['server']
    username = config['dwh']['username']
    passwd = config['dwh']['passwd']
    database = config['dwh']['database']

    cnxn = pyodbc.connect(driver='{SQL Server Native Client 11.0}',
                          host=server, database=database, user=username, password=passwd)

    sql = """
            SELECT	ChatID, UserID, Date, VIPLevel, Rating, DurationInMins, Brand, CountryGroup1, ChatType,
                    Negative_Score, Neutral_Score, Positive_Score, Sentiment, html_text
            FROM	BI_Malta.dbo.fact_chat_sentiment WITH(NOLOCK)
            WHERE	html_text IS NOT NULL
                AND Date >= GETDATE() - 30
            ORDER BY Date
          """

    df = pd.read_sql_query(sql, cnxn)

    # compress data set
    df = reduce_mem_usage(df)

    # for ctr in Country:  # Country is a list
    #    if ctr != "All Countries" and ctr != "":
    #        df3 = df3.query('Country == @Country')

    # if UserID != "":
    #    df3 = df3.query(f"UserID_newplayers == {UserID}")

    # df3.columns = ['UserID of New Player',
    #               'UserID of VIP', 'Distance (km)', 'Country']

    return df


@st.cache(ttl=60*60*KEEPALIVEHOURS)
def get_dataset_chart(Country, ShowAllPlayersDist, Distance, UserID):
    dataset_newplayers = load_obj(output_path, 'NewPlayers_Dataset')

    last_fd_date = dataset_newplayers.FirstDepositDate.max()
    df_n = dataset_newplayers[dataset_newplayers.FirstDepositDate ==
                              last_fd_date].dropna()

    # Update the category
    df_n['Category'] = 'Non-VIP with Neighbour'

    # Get the distances...
    df3 = load_obj(output_path, 'New Players closest to VIPs')

    df_n = df_n.merge(df3[['UserID_newplayers', 'distance', 'UserID_vip']].rename(columns={"distance": "Distance"}),
                      how='left',
                      left_on='UserID', right_on='UserID_newplayers').drop('UserID_newplayers', axis=1)  # .query('distance > 0 ')

    if ShowAllPlayersDist:
        # Update the category set to Non-VIP without Neighbour if distance is empty
        df_n.loc[df_n['Distance'].isna(), ['Category']
                 ] = 'Non-VIP without Neighbour'
    else:
        df_n = df_n.loc[~(df_n['Distance'].isna())]
        df_n = df_n.query(f'Distance <= {Distance}')

    # VIP players
    df_v = load_obj(output_path, 'VIP_Dataset')
    df_v = df_v.dropna()
    df_v['Category'] = 'VIP'

    # Combine dfs
    df_all = pd.concat([df_v, df_n], axis=0).reset_index(drop=True)
    df_all['Distance'].fillna(0, inplace=True)

    del df_n, df_v

    if UserID != "":
        # Impute Nas other wise cannot convert to int to object
        df_all['UserID_vip'].fillna('0', inplace=True)
        df_all['UserID_vip'] = df_all['UserID_vip'].astype(int).astype(object)

        vips_list = df_all.query(f"UserID == {UserID}")['UserID_vip'].tolist()
        df_all = df_all.query(
            "UserID == {} or UserID == @vips_list".format(UserID))

    # st.write(Country)

    if not Country:
        # List is empty
        return df_all
    elif "All Countries" in Country:
        return df_all
    else:
        # st.write('In 3')
        return df_all.query('Country == @Country')


df = get_dataset_main()
df_orig = df.copy()

date_min = df.Date.min()
date_max = df.Date.max()

viplevel_min = int(df.VIPLevel.min())
viplevel_max = int(df.VIPLevel.max())

durationinmin_min = int(df.DurationInMins.min())
durationinmin_max = int(df.DurationInMins.max())

BRANDS = sorted(df.Brand.unique())
BRANDS = ["All Brands"] + BRANDS

COUNTRIES = sorted(df.CountryGroup1.unique())
COUNTRIES = ["All Countries"] + COUNTRIES

# st.sidebar.text('You selected {}'.format(COUNTRIES))

header = st.beta_container()
body3 = st.beta_container()
body1 = st.beta_container()
body2 = st.beta_container()

with header:
    st.title('Chat Sentiments')
    st.subheader(
        f'This application shows Customer Support Chats and the predicted sentiment')
    st.text("")

st.sidebar.title("Options")
st.sidebar.markdown("Select your options")

# SELECTION TO SHOW ALL DATE (slider)

# SLIDER_DATE = st.sidebar.slider(
#    'Date and Time', min_value=date_min, max_value=date_max, value=(date_min, date_max), step=0.1, )

SLIDER_DATE = st.sidebar.date_input("Select Date", [date_min, date_max])

COUNTRIES_SELECTED = st.sidebar.multiselect(
    'Select Countries', COUNTRIES, default="All Countries")

BRANDS_SELECTED = st.sidebar.multiselect(
    'Select Brands', BRANDS, default="All Brands")

SLIDER_VIP = st.sidebar.slider(
    "Select VIP Level", min_value=viplevel_min, max_value=viplevel_max, value=(viplevel_min, viplevel_max), step=1)

SLIDER_DURATION = st.sidebar.slider(
    "Select Duration (min)", min_value=durationinmin_min, max_value=durationinmin_max, value=(durationinmin_min, durationinmin_max), step=1)

# Hide ChatID Filter in the Summary page
# TEXTBOX_CHATID = st.sidebar.text_input("Enter Chat ID")

MULTISELECT_CHATTYPE = st.sidebar.multiselect(
    'Select Chat Type', options=list(df.ChatType.unique()), default=list(df.ChatType.unique()))

MULTISELECT_SENTIMENT = st.sidebar.multiselect('Select Sentiment',
                                               ['Negative', 'Neutral', 'Positive'], default=['Negative', 'Neutral', 'Positive'])


def apply_df_filters(df, Date, Country, Brand, VIP, ChatType, Sentiment, Duration):

    # Date Filter
    df = df[(df['Date'] >= pd.to_datetime(Date[0])) &
            (df['Date'] <= pd.to_datetime(Date[1]))]

    # Country Filter
    if not Country:
        # List is empty
        df = df
    elif "All Countries" in Country:
        df = df
    else:
        df = df.query('CountryGroup1 == @Country')

    # Brand Filter
    if not Brand:
        # List is empty
        df = df
    elif "All Brands" in Brand:
        df = df
    else:
        df = df.query('Brand == @Brand')

    # VIP Filter
    df = df.query('VIPLevel >= {} and VIPLevel <= {}'.format(VIP[0], VIP[1]))

    # Chat Type
    if not ChatType:
        # List is empty
        df = df
    else:
        df = df.query('ChatType == @ChatType')

    # Sentiment Filter
    if not Sentiment:
        # List is empty
        df = df
    else:
        df = df.query('Sentiment == @Sentiment')

    # Duration Filter
    df = df.query('DurationInMins >= {} and DurationInMins <= {}'.format(
        Duration[0], Duration[1]))

    return df


df = apply_df_filters(df_orig, SLIDER_DATE, COUNTRIES_SELECTED, BRANDS_SELECTED, SLIDER_VIP, MULTISELECT_CHATTYPE,
                      MULTISELECT_SENTIMENT, SLIDER_DURATION)


with body3:
    col1, col2, col3 = st.beta_columns(3)

    with col1:
        x = df.copy()
        x['Date'] = pd.to_datetime(x['Date']).dt.round('H')
        x = x.groupby(['Date'],
                      as_index=False).size().to_frame().reset_index()
        x.columns = ['Date', 'No of Chats']

        # fig = px.area(df, facet_col="company", facet_col_wrap=2)
        # fig = go.Figure([go.Scatter(x=df['Date'], y=df['AAPL.High'])])

        fig = px.line(x, x='Date', y="No of Chats",
                      title="No of Chats by Date Time")
#        fig.update_yaxes(showgrid=False, gridwidth=1, gridcolor='LightPink')
        fig.update_layout(yaxis={'visible': True, 'showticklabels': False,
                                 'showgrid': False}, xaxis={'visible': True, 'title': ""})
        fig.update_layout({'plot_bgcolor': 'rgba(0, 0, 0, 0)'})

        fig.update_xaxes(
            rangeslider_visible=True,
            rangeselector=dict(
                buttons=list([
                    dict(count=7, label="7d", step="day", stepmode="backward"),
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            )
        )

        st.plotly_chart(fig)

    with col2:
        x = df.copy()
        x['Date'] = pd.to_datetime(x['Date']).dt.round('H')
        x = x.groupby(['Date', 'CountryGroup1'],
                      as_index=False).size().to_frame().reset_index()
        x.columns = ['Date', 'Country Group', 'No of Chats']

        fig = px.area(x, x='Date', y="No of Chats",
                      facet_col="Country Group", facet_col_wrap=4, color="Country Group")

        # fig.for_each_annotation(lambda a: a.update(text=""))
        fig.update_yaxes(matches=None, showticklabels=True,
                         visible=True, title=None)
        fig.update_xaxes(matches=None, showticklabels=True, visible=False)
        fig.update_annotations(font=dict(size=12))
        fig.update_layout(showlegend=False)
        fig.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))

        st.plotly_chart(fig)

    with col3:
        x = df.copy()
        x['Date'] = pd.to_datetime(x['Date']).dt.round('H')
        x = x.groupby(['Date', 'Sentiment'],
                      as_index=False).size().to_frame().reset_index()

        x.columns = ['Date', 'Sentiment', 'No of Chats']

        fig = px.line(x, x='Date', y="No of Chats",
                      color="Sentiment", title="Sentiment by Date Time")

        fig.update_yaxes(matches=None, showticklabels=True,
                         visible=True, title=None)
        fig.update_xaxes(matches=None, showticklabels=True,
                         visible=True, title=None)
        fig.update_annotations(font=dict(size=12))
        fig.update_layout(showlegend=True)
        fig.update_layout({'plot_bgcolor': 'rgba(0, 0, 0, 0)'})

        fig.update_xaxes(
            rangeslider_visible=True,
            rangeselector=dict(
                buttons=list([
                    dict(count=7, label="7d", step="day", stepmode="backward"),
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            )
        )

        st.plotly_chart(fig)


with body1:
    # start = time.time()
    # df_tbl = get_dataset_table(COUNTRIES_SELECTED, USERID_INPUT)
    # Same as st.write(df)
    df_tbl = st.dataframe(df.drop(['html_text'], axis=1), )
    # st.info(f'Time to get dataset: {round((time.time() - start)/ 60, 1)} mins')


with body2:
    col1, col2 = st.beta_columns(2)

    # st.write(df['html_text'][10], unsafe_allow_html=True)
    # st.markdown(df['html_text'][10], unsafe_allow_html=True,)

    with col1:

        x = df.groupby(['VIPLevel', 'Sentiment'],
                       as_index=False).size().to_frame().reset_index()
        x.columns = ['VIPLevel', 'Sentiment', 'No of Chats']

        x_negative = x.query('Sentiment == "Negative"')
        x_neutral = x.query('Sentiment == "Neutral"')
        x_positive = x.query('Sentiment == "Positive"')

        fig = go.Figure(data=[
            go.Bar(name='Negative', x=x_negative.VIPLevel,
                   y=x_negative['No of Chats']),
            go.Bar(name='Neutral', x=x_neutral.VIPLevel,
                   y=x_neutral['No of Chats']),
            go.Bar(name='Positive', x=x_positive.VIPLevel,
                   y=x_positive['No of Chats'])
        ])

        # Add title
        fig.update_layout(
            title_text='No of Chats by VIP Level and Sentiment')

        st.plotly_chart(fig)

    with col2:
        x = df[['DurationInMins', 'Sentiment']]

        x_negative = x.query('Sentiment == "Negative"')['DurationInMins']
        x_neutral = x.query('Sentiment == "Neutral"')['DurationInMins']
        x_positive = x.query('Sentiment == "Positive"')['DurationInMins']

        hist_data, group_labels = [], []

        if len(x_negative) > 0:
            hist_data.append(x_negative)
            group_labels.append('Negative')
        if len(x_neutral) > 0:
            hist_data.append(x_neutral)
            group_labels.append('Neutral')
        if len(x_positive) > 0:
            hist_data.append(x_positive)
            group_labels.append('Positive')

        # hist_data = [x_negative, x_neutral, x_positive]
        # group_labels = ['Negative', 'Neutral', 'Positive']
        # colors = ['#A56CC1', '#A6ACEC', '#63F5EF']

        # Create distplot with curve_type set to 'normal'
        fig = ff.create_distplot(hist_data, group_labels, show_hist=False,
                                 bin_size=.4, show_rug=False)

        # Add title
        fig.update_layout(
            title_text='Histogram showing Chat Duration (mins) by Sentiment')
        # fig.show()

        st.plotly_chart(fig)
