import streamlit as st
import pandas as pd
import numpy as np
import warnings
import matplotlib.pyplot as plt
import seaborn as sns

from configparser import ConfigParser
import pyodbc

from datetime import datetime
import os
import gc
import time
import io
import sys
import re
from os import path

import importlib
from helperFunctions import *
import helperFunctions
from utils import *
import utils
importlib.reload(helperFunctions)
importlib.reload(utils)

print(os.getcwd())
warnings.filterwarnings('ignore')

# Debug the application by running this in command line:
# cd /d C:\
# cd C:\Users\Jonathanm\Desktop\LiveChat Chats EDA\
# streamlit run app.py --server.port 8501 --server.address "10.13.50.37"

# import ptvsd
# 5678 is the default attach port in the VS Code debug configurations
# ptvsd.enable_attach(address=('localhost', 5678), redirect_output=True)
# ptvsd.wait_for_attach()

input_path = './Input/'
output_path = './Output/'

# Switch to wide page view
st.set_page_config(layout="wide", page_title='Chat Sentiment',  # page_icon=favicon,
                   initial_sidebar_state='auto')
# favicon being an object of the same kind as the one you should provide st.image() with (ie. a PIL array for example) or a string (url or local file path)

KEEPALIVEHOURS = 1  # Keep cache alive for 1 hours (value in seconds)


@st.cache(ttl=60*60*KEEPALIVEHOURS)
def get_dataset_main():  # Country, UserID
    config = ConfigParser()
    config.read('db.ini')

    server = config['dwh']['server']
    username = config['dwh']['username']
    passwd = config['dwh']['passwd']
    database = config['dwh']['database']

    cnxn = pyodbc.connect(driver='{SQL Server Native Client 11.0}',
                          host=server, database=database, user=username, password=passwd)

    sql = """
            SELECT	ChatID, UserID, Date, VIPLevel, Rating, DurationInMins, Brand, CountryGroup1, ChatType,
                    Negative_Score, Neutral_Score, Positive_Score, Sentiment, html_text
            FROM	BI_Malta.dbo.fact_chat_sentiment WITH(NOLOCK)
            WHERE	html_text IS NOT NULL
                AND Date >= GETDATE() - 7
            ORDER BY Date
          """

    df = pd.read_sql_query(sql, cnxn)

    # compress data set
    df = reduce_mem_usage(df)

    # for ctr in Country:  # Country is a list
    #    if ctr != "All Countries" and ctr != "":
    #        df3 = df3.query('Country == @Country')

    # if UserID != "":
    #    df3 = df3.query(f"UserID_newplayers == {UserID}")

    # df3.columns = ['UserID of New Player',
    #               'UserID of VIP', 'Distance (km)', 'Country']

    return df


@st.cache(ttl=60*60*KEEPALIVEHOURS)
def get_dataset_chart(Country, ShowAllPlayersDist, Distance, UserID):
    dataset_newplayers = load_obj(output_path, 'NewPlayers_Dataset')

    last_fd_date = dataset_newplayers.FirstDepositDate.max()
    df_n = dataset_newplayers[dataset_newplayers.FirstDepositDate ==
                              last_fd_date].dropna()

    # Update the category
    df_n['Category'] = 'Non-VIP with Neighbour'

    # Get the distances...
    df3 = load_obj(output_path, 'New Players closest to VIPs')

    df_n = df_n.merge(df3[['UserID_newplayers', 'distance', 'UserID_vip']].rename(columns={"distance": "Distance"}),
                      how='left',
                      left_on='UserID', right_on='UserID_newplayers').drop('UserID_newplayers', axis=1)  # .query('distance > 0 ')

    if ShowAllPlayersDist:
        # Update the category set to Non-VIP without Neighbour if distance is empty
        df_n.loc[df_n['Distance'].isna(), ['Category']
                 ] = 'Non-VIP without Neighbour'
    else:
        df_n = df_n.loc[~(df_n['Distance'].isna())]
        df_n = df_n.query(f'Distance <= {Distance}')

    # VIP players
    df_v = load_obj(output_path, 'VIP_Dataset')
    df_v = df_v.dropna()
    df_v['Category'] = 'VIP'

    # Combine dfs
    df_all = pd.concat([df_v, df_n], axis=0).reset_index(drop=True)
    df_all['Distance'].fillna(0, inplace=True)

    del df_n, df_v

    if UserID != "":
        # Impute Nas other wise cannot convert to int to object
        df_all['UserID_vip'].fillna('0', inplace=True)
        df_all['UserID_vip'] = df_all['UserID_vip'].astype(int).astype(object)

        vips_list = df_all.query(f"UserID == {UserID}")['UserID_vip'].tolist()
        df_all = df_all.query(
            "UserID == {} or UserID == @vips_list".format(UserID))

    # st.write(Country)

    if not Country:
        # List is empty
        return df_all
    elif "All Countries" in Country:
        return df_all
    else:
        # st.write('In 3')
        return df_all.query('Country == @Country')


df = get_dataset_main()

date_min = df.Date.min()
date_max = df.Date.max()

viplevel_min = int(df.VIPLevel.min())
viplevel_max = int(df.VIPLevel.max())

durationinmin_min = int(df.DurationInMins.min())
durationinmin_max = int(df.DurationInMins.max())

# pd.to_datetime(date_min)


BRANDS = sorted(df.Brand.unique())
BRANDS = ["All Brands"] + BRANDS

COUNTRIES = sorted(df.CountryGroup1.unique())
COUNTRIES = ["All Countries"] + COUNTRIES

# st.sidebar.text('You selected {}'.format(COUNTRIES))

header = st.beta_container()
body1 = st.beta_container()
body2 = st.beta_container()

with header:
    st.title('Chat Sentiments')
    st.subheader(
        f'This application shows Customer Support Chats and the predicted sentiment')
    st.text("")

st.sidebar.title("Options")
st.sidebar.markdown("Select your options")

# SELECTION TO SHOW ALL DATE (slider)

# SLIDER_DATE = st.sidebar.slider(
#    'Date and Time', min_value=date_min, max_value=date_max, value=(date_min, date_max), step=0.1, )

SLIDER_DATE = st.sidebar.date_input("Select Date", [date_min, date_max])

COUNTRIES_SELECTED = st.sidebar.multiselect(
    'Select Countries', COUNTRIES, default="Sweden")

BRANDS_SELECTED = st.sidebar.multiselect(
    'Select Brands', BRANDS, default="All Brands")

SLIDER_VIP = st.sidebar.slider(
    "Select VIP Level", min_value=viplevel_min, max_value=viplevel_max, value=(viplevel_min, viplevel_max), step=1)

SLIDER_DURATION = st.sidebar.slider(
    "Select Duration (min)", min_value=durationinmin_min, max_value=durationinmin_max, value=(durationinmin_min, durationinmin_max), step=1)

TEXTBOX_CHATID = st.sidebar.text_input("Enter Chat ID")

MULTISELECT_CHATTYPE = st.sidebar.multiselect(
    'Select Chat Type', options=list(df.ChatType.unique()), default=list(df.ChatType.unique()))

MULTISELECT_SENTIMENT = st.sidebar.multiselect('Select Sentiment',
                                               ['Negative', 'Neutral', 'Positive'], default=['Negative', 'Neutral', 'Positive'])

# MAPTYPE = st.sidebar.selectbox(label='Select map type', options=('stamen-terrain', 'outdoors', 'satellite', 'light', 'dark', 'carto-positron', 'open-street-map'), index=0)

with body1:
    start = time.time()
    # df_tbl = get_dataset_table(COUNTRIES_SELECTED, USERID_INPUT)
    df_tbl = st.dataframe(df, )  # Same as st.write(df)
    st.info(
        f'Time to get dataset: {round((time.time() - start)/ 60, 1)} mins')


with body2:
    col1, col2 = st.beta_columns(2)

    #    df_all = get_dataset_chart(
    #        COUNTRIES_SELECTED, SHOWALLPLAYERSDIST, SLIDER_DISTANCE, USERID_INPUT)
    # st.write(df['html_text'][10], unsafe_allow_html=True)
    # st.markdown(df['html_text'][10], unsafe_allow_html=True,)
    with col1:
        col1.subheader("Chat Transcript")
        col1.markdown(df['html_text'][10], unsafe_allow_html=True,)
        col2.markdown(df['html_text'][10], unsafe_allow_html=True,)
